from nexla.nexla_credentials import DataCredentials
from nexla.nexla_dataset import DataSet
from nexla.nexla_exceptions import *
import json
import time
from nexla.log_config import log
from datetime import datetime, timedelta


class DataSource(object):

    @staticmethod
    def create_source(auth, payload):
        """
        Create source using payload
        :Params
            auth (string): auth token
            payload (json): request body having source details
        :Returns
            DataSource: returns source object

        """
        try:
            if ("script_config" in payload):
                src_obj = DataSource(auth, payload=auth.call_url_return_json("data_sources", method="POST",
                                                                             payload=payload))
            else:
                src_obj = DataSource(auth, payload=auth.call_url_return_json("data_sources?expand=1", method="POST",
                                                                             payload=payload))
            if (src_obj.get("id") == None):
                raise Exception
            return src_obj
        except:
            raise InternalServerError

    @staticmethod
    def create_script_source(auth, id, payload):
        """
        Create script source using payload
        :Params
            auth (string): auth token
            payload (string): request body having source details
            id (string): id of a source
        :Returns
            DataSource: returns source object

        """
        try:
            src_config = DataSource(auth, payload=auth.call_url_return_json("data_sources/%s" % id, method="PUT",
                                                                            payload=payload))
            if (src_config.get("id") == None):
                raise Exception
            return src_config
        except:
            raise InternalServerError

    @staticmethod
    def update(auth, id, payload):
        """
        Update source using payload
        :Params
            auth (string): auth token
            payload (string): request body having source details
            id (string): id of a source
        :Returns
            DataSource: returns source object

        """
        if payload is None:
            raise Exception("Payload is missing to update Source")
        try:
            src_config = auth.call_url_return_json("data_sources/%s" %id, method="PUT", payload=payload)
            return src_config
        except Exception as e:
            raise InternalServerError

    @staticmethod
    def get_flows_accessors(auth, s_id):
        """
        Get flows accessors details.
        :Params
            auth (string): auth token
            s_id (string): source id
        :Returns
            Accessors: returns flows accessors details
        """
        try:
            accessors_config = auth.call_url_return_json("data_flows/data_source/%s/accessors" % s_id, method="GET")
            return accessors_config
        except:
            print("Unable to get the accessors details")
            raise InternalServerError

    @staticmethod
    def create_flows_accessors(auth, s_id, payload):
        """
        Create flows accessors using payload
        :Params
            auth (string): auth token
            s_id (string): source id
            payload (string): request body having flows accessors details
        :Returns
            Accessors: returns flows accessors details
        """
        try:
            accessors_config = auth.call_url_return_json("data_flows/data_source/%s/accessors" % s_id, method="POST", payload=payload)
            return accessors_config
        except:
            print("*** Creation of accessors will not scope for outside the environment ***")
            return False

    @staticmethod
    def create_s3_source(auth, **kwargs):
        # To be completed
        return

    @staticmethod
    def create_ftp_source(auth, **kwargs):
        # To be completed
        return

    @staticmethod
    def create_mysql_source(auth, **kwargs):
        # To be completed
        return

    @staticmethod
    def create_redshift_source(auth, **kwargs):
        # To be completed
        return

    @staticmethod
    def create_api_source(auth, **kwargs):
        # To be completed
        return

    @staticmethod
    def get_all(auth, access_role=None):
        """
        Get all sources.
        :Params
            auth (string): auth token
            access_role (string): access role of the user
        :Returns
            list: list of all source objects

        """
        src_obj_list = []
        if access_role:
            resp = auth.call_url_return_json("data_sources?expand=1&access_role=%s" % access_role)
        else:
            resp = auth.call_url_return_json("data_sources?expand=1")
        for src in resp:
            src_obj = DataSource(auth, payload=src)
            src_obj_list.append(src_obj)
        return src_obj_list

    @staticmethod
    def getAllActive(auth, access_role='collaborator'):
        """
        Get all active sources.
        :Params
            auth (string): auth token
            access_role (string): access role of the user
        :Returns
            list: list of all active source objects

        """
        src_obj_list = []
        resp = auth.call_url_return_json("data_sources?expand=1&access_role=%s" % access_role)
        # resp = auth.call_url_return_json("data_sources?expand=1")
        for src in resp:
            src_obj = DataSource(auth, payload=src)
            if src_obj.get('status') == 'ACTIVE':
                src_obj_list.append(src_obj)
        return src_obj_list

    # The main constructor for DataSource. It supports two variants, initialize from an existing source object, or from an ID.
    def __init__(self, auth, **kwargs):
        """
        Source initializer.
        :Params
            auth (string): auth token
            payload (string): request body having source details
            id (int): source id
        :Returns
            None

        """
        self.auth = auth
        if "payload" in kwargs:
            self._init_from_payload(payload=kwargs["payload"])
        elif "id" in kwargs:
            self._init_from_id(auth, kwargs["id"])
        else:
            raise Exception("Unsupported Initialization of Source Object")

    def _init_from_id(self, auth_obj, srcid):
        """
        Source initializer.
        :Params
            auth_obj (string): auth token
            id (int): source id
        :Returns
            None

        """
        resp = auth_obj.call_url_return_json("data_sources/%d?expand=1" % srcid)
        self._init_from_payload(resp)

    def _init_from_payload(self, payload):
        """
        Source initializer.
        :Params
            payload (string): request body having source details
        :Returns
            None

        """
        if payload == None:
            raise AttributeError("Missing payload to initialize Source")
        try:
            self.raw = payload
            self.attributes = {}
            self.datasets = []
            if "data_credentials" in self.raw and self.raw["data_credentials"] != None:
                self.credentials = DataCredentials(self.auth, payload=self.raw["data_credentials"])
                self.attributes["credentials_id"] = payload.get("data_credentials").get("id")
                self.attributes["credentials_name"] = payload.get("data_credentials").get("name")
            else:
                self.credentials = None

            self.attributes["raw"] = payload
            self.attributes["id"] = self.id = payload.get("id", "")
            self.attributes["name"] = payload.get("name", "")
            self.attributes["status"] = payload.get("status", "")
            self.attributes["created_at"] = payload.get("created_at", "").replace('.000Z', '')
            self.attributes["updated_at"] = payload.get("updated_at", "").replace('.000Z', '')
            self.attributes["source_type"] = payload.get("source_type", "")
            if self.attributes["source_type"] == 'nexla_rest':
                self.attributes["source_type"] = 'WebHook'
            self.attributes["dataset_count"] = len(payload.get("data_sets", []))
            for dset in payload.get("data_sets", []):
                data_set = DataSet(self.auth, payload=dset)
                self.datasets.append(data_set)

            r = payload
            loc = ""
            if "script_config" in r:
                loc = ""
            elif r["source_type"] == "rest":
                if "url.template" in r["source_config"]:
                    loc = r["source_config"]["url.template"]
                elif "rest.iterations" in r["source_config"]:
                    urls = []
                    for iter in r["source_config"]["rest.iterations"]:
                        if "url.template" in iter: urls.append(iter["url.template"])
                    loc = urls[0] if len(urls) == 1 else ",".join(urls)
            elif (r["source_type"] in ["ftp", "s3", "dropbox", "azure_data_lake","gcs","gdrive"]):
                if "path" in r["source_config"]:
                    loc = str(r["source_type"]) + "://" + r["source_config"]["path"].lstrip("/")
                elif "bucket" in r["source_config"] and "prefix" in r["source_config"]:
                    loc = str(r["source_type"]) + "://"
                    if str(r["source_config"]["bucket"]) != '' and str(r["source_config"]["bucket"]) != "/":
                        loc += str(r["source_config"]["bucket"]) + '/'
                    if r["source_config"]["prefix"]: loc += str(r["source_config"]["prefix"])
            elif (r["source_type"] in ["mysql", "redshift", "postgres", "snowflake","bigquery"]):
                db = r["source_config"].get("database", "")
                sc = r["source_config"].get("schema", "")
                tb = r["source_config"].get("table", "")
                loc = db
                if sc:
                    loc += "." + sc if loc else sc
                if tb:
                    loc += "." + tb if loc else tb
            elif r["source_type"] == 'nexla_rest':
                loc = "https://hooks-" + self.auth.get_host_name() + "/data/" + str(self.id)
            self.attributes["location"] = loc

            if "poll_frequency" in r["source_config"]:
                self.attributes["frequency"] = r["source_config"]["poll_frequency"]
            elif "start.cron" in r["source_config"]:
                self.attributes["frequency"] = r["source_config"]["start.cron"]
            else:
                self.attributes["frequency"] = 'unknown'

            self.attributes['owner'] = payload["owner"]["full_name"]
            self.attributes['org'] = payload["org"]["name"]
        except:
            print(json.dumps(payload, indent=4))
            raise Exception("Unable to intialize the source")

    def get_export(self):
        """
        Get templatized source details.
        :Returns
            Dict: returns templatized source details

        """
        try:
            src_create_tmplt = {}
            src_create_tmplt["name"] = self.raw["name"]
            src_create_tmplt["description"] = self.raw["description"]
            if "data_credentials" in self.raw and self.raw["data_credentials"]:
                src_create_tmplt["data_credentials"] = "<" + str(self.raw["data_credentials"]["id"]) + ": " + str(
                    self.raw["data_credentials"]["name"]) + ">"
            src_create_tmplt["source_type"] = self.raw["source_type"]
            src_create_tmplt["ingest_method"] = self.raw["ingest_method"]
            src_create_tmplt["source_config"] = self.raw["source_config"]
            return src_create_tmplt
        except:
            print(json.dumps(self.raw, indent=4))
            raise

    @staticmethod
    def get_quarantine_samples(auth, id, count):
        """
        Get qurantine samples for a source
        :Params
            id (int): source id
        :Returns
            string: quarantine samples

        """
        p = {"event_count": count, "latest": True}
        resp = auth.call_url_return_json("data_sources/%d/probe/quarantine/sample" % id, method="POST", payload=p)
        return resp

    @staticmethod
    def get_quarantine_files(auth, id, count):
        """
        Get qurantine files for a source
        :Params
            id (int): source id
        :Returns
            string: quarantine files
        """
        p = {"access_role": "collaborator", "page": 1, "size": count, "orderby": "created_at", "sortorder": "desc", "status": ''}
        resp = auth.call_url_return_json("data_sources/%d/metrics/quarantine_files" % id, method="GET", payload=p)
        return resp

    @staticmethod
    def get_notifications(auth, id, count, type):
        p = {"event_count": count, "latest": True}
        resp = auth.call_url_return_json(
            "/notifications?access_role=collaborator&resource_id=%d&resource_type=%s&page=1&per_page=1&sort_by=updated_at&sort_order=DESC" % (
            id, type), method="GET", payload=p)
        return resp

    @staticmethod
    def get_src_type_from_vendor_endpoint(auth, endpoint_id):
        """
        Display name of the vendor from the vendor endpoint
        :Params
            auth (string): auth token
            endpoint_id (string): vendor endpoint id
        :Returns
            Name: returns vendor endpoint name

        """
        resp = auth.call_url_return_json("/vendor_endpoints/%s" %endpoint_id, 'GET')
        return resp.get("vendor").get("display_name")

    @staticmethod
    def activate(auth, id):
        """
        Activate a source
        :Params
            id (int): source id
        :Returns
            bool: The return value is True if the source gets activated, False otherwise.

        """
        resp = auth.call_url_return_json("/data_sources/%d/activate" % id, method="PUT")
        if resp["status"]:
            if resp["status"] != "ACTIVE":
                log.error("Activation failed.")
                raise Exception("Source not activated")
            else:
                return True
        return False

    @staticmethod
    def pause(auth, id):
        """
        Pause a source
        :Params
            id (int): source id
        :Returns
            bool: The return value is True if the source gets paused, False otherwise.

        """
        resp = auth.call_url_return_json("/data_sources/%d/pause" % id, method="PUT")
        if resp["status"]:
            if resp["status"] != "PAUSED":
                log.error("Failed to pause")
                raise Exception("Source not paused")
            else:
                return True
        return False

    @staticmethod
    def get_aggregate_metrics(auth, id, days=7, start_time=None, end_time=None):
        """
        Get aggregate metics of given source id
        :param auth: auth object
        :param id: source id
        :param days: no of days ago
        :param start_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :param end_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :return: list of dictionaries
        """
        if end_time and not start_time:
            raise Exception("Required start time")
        elif not end_time:
            current_datetime = datetime.utcnow()
            end_time = current_datetime.strftime("%Y-%m-%dT%H:%M:%S")
            if not start_time: start_time = (current_datetime - timedelta(days=days)).strftime("%Y-%m-%d")
        resp = auth.call_url_return_json(
            "data_sources/%d/metrics?from=%s&to=%s&aggregate=1" % (id, start_time, end_time))
        return resp["metrics"]

    @staticmethod
    def get_file_metrics(auth, id, days=7, start_time=None, end_time=None, src_type=""):
        """
        Get aggregate metics of given source id
        :param auth: auth object
        :param id: source id
        :param days: no of days ago
        :param start_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :param end_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :return: list of dictionaries
        """
        if end_time and not start_time:
            raise Exception("Required start time")
        elif not end_time:
            current_datetime = datetime.utcnow()
            end_time = current_datetime.strftime("%Y-%m-%dT%H:%M:%S")
            if not start_time: start_time = (current_datetime - timedelta(days=days)).strftime("%Y-%m-%dT00:00:00")
            if start_time > end_time: return None
        file_sources = ["s3", "ftp", "dropbox", "box", "azure_blb", "gdrive", "azure_data_lake", "delta_lake_azure_blb", "delta_lake_s3", "delta_lake_azure_data_lake", ]

        url = "data_sources/%d/metrics/files?page=%d&size=%d&orderby=lastIngested&sortorder=desc&from=%s&to=%s&aggregate=1"
        if src_type not in file_sources:
            url = "data_sources/%d/metrics/run_summary?page=%d&size=%d&orderby=runId&sortorder=desc&from=%s&to=%s"
        remain_pages = 1
        page = 0
        page_size = 100
        metrics = []
        while remain_pages >= 1:
            page += 1
            resp = auth.call_url_return_json(
                url % (id, page, page_size, start_time, end_time))
            if src_type == "gdrive":
                for item in resp['metrics']["data"]:
                    item["name"] = item['metadata']['display_path']
            metrics.extend(resp["metrics"]["data"])
            if "meta" in resp["metrics"]:
                total_pages = resp["metrics"]["meta"]["pageCount"]
                if total_pages > 2:
                    page = 0
                    page_size = resp["metrics"]["meta"]["totalCount"]
                    metrics = []
                    remain_pages = 1
                else:
                    remain_pages = total_pages - page
        if src_type not in file_sources:
            new_metrics = []
            for metric in metrics:
                new_metric = {}
                for k, v in metric.items():
                    if k == "runId":
                        new_metric["lastIngested"] = datetime.utcfromtimestamp(v / 1000).strftime(
                            '%Y-%m-%dT%H:%M:%SZ')
                    else:
                        new_metric[k] = v
                new_metrics.append(new_metric)
            return new_metrics
        return metrics

    def get_dataset_count(self):
        """
        Get number of datasets of the source
        :Params
            id (int): source id
        :Returns
            int: number of datasets of the source

        """
        return len(self.datasets)

    def get_full_object(self):
        return self.raw

    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr, "")

    def probe(self):
        """
        Check validity of source credentials
        :Returns
            int: response code

        """
        return self.credentials.probe()

    def probe_list(self):
        """
        List the top-level folders, buckets or tables in the external source
        :Returns
            string: response of probe call

        """
        return self.credentials.probe_list()

    def probe_tree(self):
        """
        Inspect the tree structure in the external source to a particular depth
        :Returns
            string: response of probe call

        """
        bucket = self.raw["source_config"]["bucket"]
        prefix = self.raw["source_config"]["prefix"]
        payload = {"bucket": bucket, "prefix": prefix, "depth": 2}
        return self.credentials.probe_tree(payload)

    def wait_till_dataset_is_detected(self, max_time=900, poll_interval=1, src_dataset_count = 1):
        """
        Get dataset id on its detection
        :Params
            max_time (int): maximum number of seconds of wait for dataset detection
            poll_interval (int): number of seconds of wait between two checks
        :Returns
            int: id of the detected dataset

        """
        resp = self.auth.call_url_return_json("/data_sources/%d?expand=1" % self.get("id"))
        total_sleep_time = 0
        src_dataset_id = []
        log.info("Waiting for dataset to be detected..")
        # print("Expected Source dataset count -----> %s" %src_dataset_count)
        is_source_active = True
        while total_sleep_time<=max_time:
            resp = self.auth.call_url_return_json("/data_sources/%d?expand=1" % self.get("id"))
            if len(resp["data_sets"]) != 0:
                if (src_dataset_count > 1):
                    if not is_source_active:
                        print("Activating Source now ....")
                        is_activated = DataSource.activate(self.auth, self.get("id"))
                        if (is_activated == True):
                            print("Successfully activated, Waiting for Next datasets to be detected")
                            is_source_active = True
                        else:
                            print("Activation failed")

                    # print("Inside Source dataset count > 0")
                    if(len(resp["data_sets"]) >= src_dataset_count):
                        for dset in resp["data_sets"]:
                            src_dataset_id.append(dset["id"])
                        break
                    else:
                        total_sleep_time += poll_interval
                        log.info("Sleeping for %d sec" % poll_interval)
                        time.sleep(poll_interval)
                        log.info("Total sleep time : %d" % total_sleep_time)

                else:
                    for dset in resp["data_sets"]:
                        src_dataset_id.append(dset["id"])
                    break
            else:
                total_sleep_time += poll_interval
                log.info("Sleeping for %dsec"%poll_interval)
                time.sleep(poll_interval)
                log.info("Total sleep time : %d"%total_sleep_time)
        if total_sleep_time > max_time:
            log.info("Waiting time exceeded %d sec"%max_time)
            return None

        log.info("Detected src_dataset_ids : %s" % src_dataset_id)
        return src_dataset_id


    def __str__(self):
        return ("ID: %d, Name: %s" % (self.attributes.get("id", ""), self.attributes.get("name", "")))
