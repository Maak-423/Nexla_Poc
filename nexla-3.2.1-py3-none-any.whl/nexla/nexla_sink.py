from nexla.nexla_credentials import DataCredentials
import re, os, boto3
from nexla.log_config import log
from datetime import datetime, timedelta

file_sinks = ["s3", "ftp", "dropbox", "box", "gdrive", "gcs", "azure_data_lake", "delta_lake_azure_blb","delta_lake_s3", "delta_lake_azure_data_lake","azure_blb"]

class DataSink(object):

    @staticmethod
    def get_all(auth, access_role=None):
        """
        Get all sinks.
        :Params
            auth (string): auth token
        :Returns
            list: list of all sink objects

        """
        sink_obj_list = []
        if access_role:
            resp = auth.call_url_return_json("data_sinks?expand=1&access_role=%s" % access_role)
        else:
            resp = auth.call_url_return_json("data_sinks?expand=1")
        for sink in resp:
            sink_obj = DataSink(auth, payload=sink)
            sink_obj_list.append(sink_obj)
        return sink_obj_list

    def __init__(self, auth, **kwargs):
        """
        Sink initializer.
        :Params
            auth (string): auth token
            payload (string): request body having sink details
            id (int): sink id
        :Returns
            None

        """
        self.auth = auth
        if "payload" in kwargs:
            self._init_from_payload(kwargs["payload"])
        elif "id" in kwargs:
            self._init_from_id(auth, kwargs["id"])
        else:
            raise Exception("Unsupported Initialization of Source Object")

    def _init_from_id(self, auth_obj, sinkid):
        """
        Sink initializer.
        :Params
            auth_obj (string): auth token
            sinkid (int): sink id
        :Returns
            None

        """
        resp = auth_obj.call_url_return_json("data_sinks/%d?expand=1" % sinkid)
        self._init_from_payload(payload=resp)

    def _init_from_payload(self, payload):
        """
        Sink initializer.
        :Params
            payload (string): request body having sink details
        :Returns
            None

        """
        if payload == None:
            raise Exception("Missing payload to initialize Source")
        self.raw = payload
        self.attributes = {}
        if "data_credentials" in self.raw and self.raw["data_credentials"] != None and len(
                self.raw["data_credentials"]) > 0:
            self.credentials = DataCredentials(self.auth, payload=self.raw["data_credentials"])
            self.attributes["credentials_id"] = payload.get("data_credentials").get("id")
            self.attributes["credentials_name"] = payload.get("data_credentials").get("name")
        else:
            self.credentials = None
            self.attributes["credentials_id"] = None
            self.attributes["credentials_name"] = None
        self.attributes["raw"] = payload
        self.attributes["id"] = payload.get("id", "")
        self.attributes["name"] = payload.get("name", "")
        self.attributes["status"] = payload.get("status", "")
        self.attributes["created_at"] = payload.get("created_at", "").replace('.000Z', '')
        self.attributes["updated_at"] = payload.get("updated_at", "").replace('.000Z', '')
        self.attributes["sink_type"] = payload.get("sink_type", "")
        self.attributes["sink_config"] = payload.get("sink_config", {})
        self.attributes["data_set_id"] = payload.get("data_set_id", "")
        if not self.attributes["status"] and payload.get("data_set"):
            self.attributes["status"] = payload.get("data_set").get("status")

        r = payload
        loc = ""
        if r["sink_type"] == "rest" and "url.template" in r["sink_config"]:
            loc = r["sink_config"]["url.template"]
        elif (r["sink_type"] in ["ftp", "s3", "dropbox", "azure_data_lake", "gcs", "gdrive"]):
            if "path" in r["sink_config"]:
                loc = str(r["sink_type"]) + "://" + r["sink_config"]["path"].lstrip("/")
            elif "bucket" in r["sink_config"] and "prefix" in r["sink_config"]:
                loc = str(r["sink_type"]) + "://"
                if str(r["sink_config"]["bucket"]) != '' and str(r["sink_config"]["bucket"]) != "/":
                    loc += str(r["sink_config"]["bucket"]) + '/'
                if r["sink_config"]["prefix"]: loc += str(r["sink_config"]["prefix"])
            if "output.dir.name.pattern" in r["sink_config"]:
                loc += "/" + r["sink_config"]["output.dir.name.pattern"]
        elif (r["sink_type"] in ["mysql", "redshift", "snowflake", "bigquery", "oracle_autonomous", "postgres"]):
            db = r["sink_config"].get("database", "")
            sc = r["sink_config"].get("schema", "")
            tb = r["sink_config"].get("table", "")
            loc = db
            if sc:
                loc += "." + sc if loc else sc
            if tb:
                if loc:
                    loc += "." + tb
                else:
                    loc = tb

        self.attributes["location"] = loc

    def probe(self):
        """
        Check validity of sink credentials
        :Returns
            int: response code

        """
        return self.credentials.probe()

    def probe_list(self):
        """
        List the top-level folders, buckets or tables in the external sink
        :Returns
            string: response of probe call

        """
        return self.credentials.probe_list()

    def probe_tree(self):
        """
        Inspect the tree structure in the external sink to a particular depth
        :Returns
            string: response of probe call

        """
        payload = {"depth": 2}
        return self.credentials.probe_tree(payload)

    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr, "")

    def get_export(self):
        """
        Get templatized sink details.
        :Returns
            Dict: returns templatized sink details

        """
        sink_output_obj = {}
        resp = self.raw
        sink_output_obj['name'] = resp['name']
        sink_output_obj['description'] = resp['description']
        sink_output_obj['sink_config'] = resp['sink_config']
        sink_output_obj['sink_type'] = resp['sink_type']
        if resp['sink_type'] == 'data_map':
            sink_output_obj["data_map_id"] = resp.get('data_map_id')
            # sink_output_obj["data_map"] = resp.get('data_map')
        if sink_output_obj.get('data_credentials'):
            sink_output_obj["data_credentials"] = "<" + str(resp["data_credentials"]["id"]) + ": " + str(resp["data_credentials"]["name"]) + ">"
        sink_output_obj["data_set_id"] = resp["data_set_id"]
        return sink_output_obj

    @staticmethod
    def get_quarantine_samples(auth, id, count):
        """
        Get qurantine samples for a sink
        :Params
            id (int): sink id
        :Returns
            string: quarantine samples

        """
        p = {"event_count": count, "latest": True}
        resp = auth.call_url_return_json("data_sinks/%d/probe/quarantine/sample" % id, method="POST", payload=p)
        return resp

    @staticmethod
    def get_quarantine_files(auth, id, count):
        """
        Get qurantine files for a sink
        :Params
            id (int): sink id
        :Returns
            string: quarantine files

        """
        p = {"access_role": "collaborator","page": 1, "size": count, "orderby": "created_at", "sortorder": "desc", "status": ''}
        resp = auth.call_url_return_json("data_sinks/%d/metrics/quarantine_files" % id, method="GET", payload=p)
        return resp

    @staticmethod
    def create(auth, payload):
        """
        Create sink using payload
        :Params
            auth (string): auth token
            payload (string): request body having sink details
        :Returns
            DataSink: returns sink object

        """
        datasinkobj = DataSink(auth, payload=auth.call_url_return_json("/data_sinks?expand=1", method="POST",
                                                                       payload=payload))
        if (datasinkobj.get("id") == None):
            raise Exception("Error Creating Sink")
        return datasinkobj

    @staticmethod
    def update(auth, payload, sink_id):
        """
        Update sink using payload
        :Params
            auth (string): auth token
            payload (string): request body having sink details
            sink_id (string): id of a sink
        :Returns
            DataSink: returns sink object

        """
        payload = auth.call_url_return_json("/data_sinks/%s?expand=1" % sink_id, method="PUT", payload=payload)
        return payload

    @staticmethod
    def create_script_sink(auth, payload, id):
        """
        Create script sink using payload
        :Params
            auth (string): auth token
            payload (string): request body having sink details
            id (string): id of a sink
        :Returns
            DataSink: returns sink object

        """
        datasinkobj = DataSink(auth, payload=auth.call_url_return_json("/data_sinks/%s?expand=1" % id, method="PUT",
                                                                       payload=payload))
        if (datasinkobj.get("id") == None):
            raise Exception("Error Creating Sink")
        return datasinkobj

    @staticmethod
    def get_aggregate_metrics(auth, id, days=7, start_time=None, end_time=None):
        """
        Get aggregate metics of given destiation id
        :param auth: auth object
        :param id: destination id
        :param days: no of days ago
        :return: list of dictionaries
        """
        if end_time and not start_time:
            raise Exception("Required start time")
        elif not end_time:
            current_datetime = datetime.utcnow()
            end_time = current_datetime.strftime("%Y-%m-%dT%H:%M:%S")
            if not start_time: start_time = (current_datetime - timedelta(days=days)).strftime("%Y-%m-%d")
        resp = auth.call_url_return_json("data_sinks/%d/metrics?from=%s&to=%s&aggregate=1" % (id, start_time, end_time))
        return resp["metrics"]

    @staticmethod
    def get_file_metrics(auth, id, days=7, start_time=None, end_time=None, sink_type=""):
        """
        Get aggregate metics of given source id
        :param auth: auth object
        :param id: sink id
        :param days: no of days ago
        :param start_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :param end_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :return: list of dictionaries
        """
        if end_time and not start_time:
            raise Exception("Required start time")
        elif not end_time:
            current_datetime = datetime.utcnow()
            end_time = current_datetime.strftime("%Y-%m-%dT%H:%M:%S")
            if not start_time: start_time = (current_datetime - timedelta(days=days)).strftime("%Y-%m-%dT00:00:00")
            if start_time > end_time: return None

        url = "data_sinks/%d/metrics/files?page=%d&size=%d&orderby=lastWritten&sortorder=desc&from=%s&to=%s&aggregate=1"
        if sink_type not in file_sinks:
            url = "data_sinks/%d/metrics/run_summary?page=%d&size=%d&orderby=lastWritten&sortorder=desc&groupby=lastWritten&from=%s&to=%s"

        remain_pages = 1
        page = 0
        page_size = 100
        metrics = []
        while remain_pages >= 1:
            page += 1
            resp = auth.call_url_return_json(
                url % (id, page, page_size, start_time, end_time))
            if sink_type == "gdrive":
                for item in resp['metrics']["data"]:
                    item["name"] = item['metadata']['display_path']
            metrics.extend(resp["metrics"]["data"])
            if "meta" in resp["metrics"]:
                total_pages = resp["metrics"]["meta"]["pageCount"]
                if total_pages > 2:
                    page = 0
                    page_size = resp["metrics"]["meta"]["totalCount"]
                    metrics = []
                    remain_pages = 1
                else:
                    remain_pages = total_pages - page

        if sink_type not in file_sinks:
            new_metrics = []
            for metric in metrics:
                new_metric = {}
                for k,v in metric.items():
                    if k in ["runId","lastWritten"]:
                        new_metric["lastWritten"] = datetime.utcfromtimestamp(v/1000).strftime('%Y-%m-%dT%H:%M:%SZ')
                    else:
                        new_metric[k] = v
                new_metrics.append(new_metric)
            return new_metrics

        return metrics

    @staticmethod
    #TO DO get_sink_filesList(run id as parameter)
    def get_sink_filesList(auth, id, days=7, start_time=None, end_time=None, download_path="/tmp"):
        """
        Get aggregate metics of given source id
        :param auth: auth object
        :param id: sink id
        :param days: no of days ago
        :param start_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :param end_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :return: list of dictionaries):
        """
        data_sink_obj = DataSink(auth, id=id)
        sink_type = data_sink_obj.get("sink_type")
        sink_file_list = []
        if sink_type in file_sinks:
            metrics = DataSink.get_file_metrics(auth, id, days=days, start_time=start_time, end_time=end_time,
                                                sink_type=sink_type)
            if ('/' in data_sink_obj.get("sink_config").get("path")):
                bucket_name = re.match('(.*?)/', data_sink_obj.get("sink_config").get("path")).group(1)
            else:
                bucket_name = data_sink_obj.get("sink_config").get("path")
            for file in metrics:
                if bucket_name != "":
                    sink_file_list.append(bucket_name + '/' + file["name"])
                else:
                    sink_file_list.append(file["name"])
            return sink_file_list

    @staticmethod
    def download_files_from_s3(file_paths, download_path = "/tmp"):
        """
        Get aggregate metics of given source id
        :param file_paths: list of s3 file paths or file path to be downloaded
        :param download_path:  path to download s3 files
        """
        try:
            s3 = boto3.client('s3')
        except:
            raise Exception("No/Invalid S3 credentials, please validate")
        try:
            if not os.path.exists(download_path):
                raise Exception ("No such Directory %s" %download_path)

            if(type(file_paths) == list):
                for s3_path in file_paths:
                    file_name = os.path.basename(s3_path)
                    path_parts = s3_path.split("/")
                    bucket = path_parts.pop(0)
                    key = "/".join(path_parts)
                    # print(bucket, key)
                    download_file_path = os.path.join(download_path, file_name)
                    print("Downloading %s to %s" % ((bucket + '/' + key), download_file_path))
                    s3.download_file(bucket, key, download_file_path)
                print("Downloaded files to %s successfully" % download_path)
            elif(type(file_paths) == str):
                file_name = os.path.basename(file_paths)
                path_parts = file_paths.split("/")
                bucket = path_parts.pop(0)
                key = "/".join(path_parts)
                download_file_path = os.path.join(download_path, file_name)
                print("Downloading %s to %s" % ((bucket + '/' + key), download_file_path))
                s3.download_file(bucket, key, download_file_path)
                print("Downloaded file to %s successfully" % download_path)
            else:
                raise Exception("Invalid File path")
        except Exception as e:
            print("Downloading file failed with \"%s\" error"%e)

    @staticmethod
    def activate(auth, sink_id):
        """
        Activate a source
        :Params
            id (int): source id
        :Returns
            bool: The return value is True if the sink gets activated, False otherwise.

        """
        resp = auth.call_url_return_json("/data_sinks/%d/activate" % sink_id, method="PUT")
        if resp["status"]:
            if resp["status"] != "ACTIVE":
                log.error("Activation failed.")
                raise Exception("Source not activated")
            else:
                return True
        return False

    @staticmethod
    def pause(auth, sink_id):
        """
        Pause a source
        :Params
            id (int): source id
        :Returns
            bool: The return value is True if the sink gets paused, False otherwise.

        """
        resp = auth.call_url_return_json("/data_sinks/%d/pause" % sink_id, method="PUT")
        if resp["status"]:
            if resp["status"] != "PAUSED":
                log.error("Failed to pause")
                raise Exception("Source not paused")
            else:
                return True
        return False

    def __str__(self):
        return ("ID: %d, Name: %s" % (self.attributes.get("id", ""), self.attributes.get("name", "")))


sink_create_template_csv = {
    "name": "",
    "sink_type": "",
    "data_credentials": 0,
    "sink_config": {
        "mapping": {
            "mode": "manual",
            "mapping": {}
        },
        "prefix": "",
        "poll_frequency": "Hour",
        "output.dir.name.pattern": "{yyyy}-{MM}-{dd}",
        "data_format": "",
        "bucket": ""
    },
    "data_sub_id": 0
}

sink_create_template_json = {
    "name": "",
    "sink_type": "",
    "data_credentials": 0,
    "sink_config": {
        "prefix": "",
        "region": "us-east-1",
        "poll_frequency": "Hour",
        "output.dir.name.pattern": "{yyyy}-{MM}-{dd}",
        "data_format": "",
        "bucket": ""
    },
    "data_sub_id": 0
}

sink_create_template_mysql = {
    "name": "",
    "sink_type": "",
    "sink_config": {
        "insert.mode": "INSERT",
        "table": "",
        "database": "",
        "primary.key": "",
        "mapping": {
            "mode": "manual",
            "mapping": {}
        }
    },
    "data_sub_id": 0
}

sink_create_template_api = {
    "name": "",
    "data_sub_id": 0,
    "sink_type": "rest",
    "sink_config": {
        "body.template": "{message.json}",
        "method": "POST",
        "content.type": "application/json",
        "sink_type": "rest",
        "url.template": "",
        "request.parallelism.count": 10
    },

}
