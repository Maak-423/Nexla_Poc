import logging
from logging import handlers
import os

log_file=os.getenv("NEXLA_CLI_LOG","nexla.log")
default_level=logging.DEBUG
log = logging.getLogger()
if not log.handlers:
    log.setLevel(default_level)
    format = logging.Formatter("%(asctime)s.%(msecs)03d] %(levelname)s %(module)s - %(funcName)s: %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

    """ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(format)
    log.addHandler(ch)"""

    fh = handlers.RotatingFileHandler(log_file, maxBytes=(1048576 * 5), backupCount=7)
    fh.setFormatter(format)
    log.addHandler(fh)
