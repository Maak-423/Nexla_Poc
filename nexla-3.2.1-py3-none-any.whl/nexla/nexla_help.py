from nexla import __version__

help = {
    "main": """Nexla Command Line Interface (CLI) v%s
Description:
    CLI to interact with Nexla resources.

Usage:
    nexla <object> <action> [parameters]

Objects:
    source
        Get details of data sources
    destination
        Get details of destinations
    lookup
        Get details of both static and dynamic lookups
    credential
        Get details of credentials
    dataset
        Get details of datasets
    flows
        Get details of flows or import/export flows
    env
        Configure Nexla CLI environment

Examples:
    nexla source list
    nexla dataset list
        """ % __version__,
    "source":
        {"help": """CLI for nexla sources
Description:
    CLI to interact with Nexla data sources (ftp,s3,mysql,etc).

Usage:
    nexla source <action> [parameters]

Actions:
    list
        List available data sources
    get
        Get source configuration of a given source id
    pause
        Pause a source
    activate
        Activate a source
    sample-quarantine 
        Get sample quarantine records for a source
    metrics
        Get aggregate metrics for a source
    read-stats
        Get read stats for a source

Examples:
    nexla source list
    nexla source get 8608
    nexla source pause 8608
    nexla source activate 8608
    nexla source sample-quarantine 8608

""",
         "list":
             {"help": """Description:
    List of data sources available in nexla
Usage:
    nexla source list

Examples:
nexla source list
"""},
         "get":
             {"help": """Description:
Get the source configuration of a source by id
Usage:
    nexla source get <source_id>

Examples:
    nexla source get 8608
"""
              },
         "pause":
             {"help": """Description:
    Pause a source by id
Usage:
    nexla source pause <source_id>

Examples:
    nexla source pause 8608
"""
              },
         "sample-quarantine":
             {"help": """Description:
    Get sample quarantine records for a source
Usage:
    nexla source sample-quarantine <source_id> [options]

Options:
    -c,--count (int)   Number of quarantine samples to be displayed
    -f,--quarantine_files     Get the quarantine files for a source

Examples:
    nexla source sample-quarantine 8608
"""
              },
         "activate":
             {"help": """Description:
    Activate a source by id 
Usage:
    nexla source activate <source_id>

Examples:
    nexla source activate 8608
"""
              },
         "metrics":
             {"help": """Description:
    Get aggregate metrics for a source
Usage:
    nexla source metrics <source_id> [options]

Options:
    -d,--days (int)   Number of days to get metrics for, default is 7
    -s,--start (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format
    -e,--end (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format, default is current time

Examples:
    nexla source metrics 8608
"""
              },
         "read-stats":
             {"help": """Description:
    Get read stats for a source
Usage:
    nexla source read-stats <source_id> [options]

Options:
    -d,--days (int)   Number of days to get read stats for, default is 7
    -s,--start (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format
    -e,--end (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format, default is current time

Examples:
    nexla source read-stats 8608
"""
              }
         },
    "dataset":
        {"help": """CLI for nexla dataset
Description:
    CLI to interact with Nexla datasets

Usage:
    nexla dataset <action> [parameters]

Actions:
    list
        List available datasets
    get
        Get the dataset configuration by dataset id
    pause
        Pause dataset
    activate
        Activate dataset
    sample
        Get sample records for a dataset
    sample-quarantine
        Get sample quarantine records for a dataset
    metrics
        Get aggregate metrics for a dataset

Examples:
    nexla dataset list
    nexla dataset get 19609
    nexla dataset pause 19609
    nexla dataset activate 19609
    nexla dataset sample 19609
    nexla dataset sample-quarantine 19609
""",
         "list":
             {"help": """Description:
    List of datasets available in Nexla
Usage:
    nexla dataset list

Examples:
nexla dataset list
"""},
         "get":
             {"help": """Description:
Get the configuration of given dataset id

Usage:
    nexla source get <dataset_id> [options]

Options: 
 -t,--transform    Get the transform details only

Examples:
    nexla dataset get 19609
"""
              },
         "pause":
             {"help": """Description:
    Pause the given dataset id
Usage:
    nexla dataset pause <dataset_id>

Examples:
    nexla dataset pause 19609
"""
              },
         "sample":
             {"help": """Description:
    Get the samples for a dataset by id
Usage:
    nexla dataset sample <dataset_id> [options]

Options:
    -c,--count (int)              Number of samples to be displayed, default is 10
    -t,--transform       Transformed output for the samples are displayed if this option is given, This option will be considered defaultly until user not pass other options.
    -i,--show_inputs     Inputs for the samples are displayed if this option is given.

Examples:
    nexla dataset sample 19609
"""
              },
         "sample-quarantine":
             {"help": """Description:
    Get sample quarantine records for given dataset by id
Usage:
    nexla dataset sample-quarantine <dataset_id> [options]

Options:
    -c,--count (int)   Number of quarantine samples to be displayed
    -f,--quarantine_files    Get the quarantine files for given dataset

Examples:
    nexla dataset sample-quarantine 19609
"""
              },
         "activate":
             {"help": """Description:
    Activate dataset by id
Usage:
    nexla dataset activate <dataset_id>

Examples:
    nexla dataset activate 19609
"""
              },
         "metrics":
             {"help": """Description:
    Get aggregate metrics for a dataset
Usage:
    nexla dataset metrics <dataset_id> [options]

Options:
    -d,--days (int)   Number of days to get metrics for, default is 7
    -s,--start (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format
    -e,--end (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format, default is current time

Examples:
    nexla dataset metrics 19609
"""
              }
         },
    "destination":
        {"help": """CLI for nexla destination
Description:
    CLI to interact with Nexla data destinations (ftp,s3,mysql,etc).

Usage:
    nexla destination <action> [parameters]

Actions:
    list
        List available destinations
    get
        Get destination configuration for destination by id
    pause
        Pause destination
    activate
        Activate destination
    sample-quarantine
        Get sample quarantine records for a destination
    metrics
        Get aggregate metrics for a destination
    write-stats
        Get write stats for a destination
Examples:
    nexla destination list
    nexla destination get 7976
    nexla destination pause 7976
    nexla destination activate 7976
    nexla destination sample-quarantine 7976
""",
         "list":
             {"help": """Description:
    List of destinations available in nexla
Usage:
    nexla destination list

Examples:
nexla destination list
"""},
         "get":
             {"help": """Description:
Get destination configuration for a destination by id
Usage:
    nexla destination get <destination_id>

Examples:
    nexla destination get 7976
"""
              },
         "pause":
             {"help": """Description:
    Pause destination
Usage:
    nexla destination pause <destination_id>

Examples:
    nexla destination pause 7976
"""
              },
         "sample-quarantine":
             {"help": """Description:
    Get sample quarantine records for a destination by id
Usage:
    nexla destination sample-quarantine <destination_id> [options]

Options:
    -c,--count (int)   Number of quarantine samples to be displayed
    -f,--quarantine_files     Get the quarantine files for a destination

Examples:
    nexla destination sample-quarantine 7976
"""
              },
         "activate":
             {"help": """Description:
    Activate destination by id
Usage:
    nexla destination activate <destination_id>

Examples:
    nexla destination activate 7976
"""
              },
         "metrics":
             {"help": """Description:
    Get aggregate metrics for a destination
Usage:
    nexla destination metrics <dest_id> [options]

Options:
    -d,--days (int)   Number of days to get metrics for, default is 7
    -s,--start (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format
    -e,--end (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format, default is current time

Examples:
    nexla destination metrics 7976
"""
              },
         "write-stats":
             {"help": """Description:
    Get write stats for a destination by id
Usage:
    nexla destination write-stats <dest_id> [options]

Options:
    -d,--days (int)   Number of days to get read stats for, default is 7
    -s,--start (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format
    -e,--end (string)   UTC datetime in '%Y-%m-%dT%H:%M:%S' format, default is current time

Examples:
    nexla destination write-stats 7976
"""
              }

         },
"flows":
        {"help": """CLI for nexla flows
Description:
    CLI to interact with Nexla flows.

Usage:
    nexla flows <action> [parameters]

Actions:
    get
        Displays the complete flow including sources, datasets and destinations.
    pause
        Pause the complete flow
    activate
        Activate the complete flows
    export
        Export Development Flow Specification
    import
        Import Development Flow Specification from exported file.
    update
        Update the existing flow with updated configurations
    clone
        Clone the flows within the environment
    delete
        Delete the complete flows
Examples:
    nexla flows get 9311
    nexla flows pause 9311
""",

         "get":
             {"help": """Description:
Displays the complete flow including sources, datasets and destinations.
Usage:
    nexla flows get <source_id>

Examples:
    nexla flows get 9311
"""
              },
         "pause":
             {"help": """Description:
    Pause the complete flow
Usage:
    nexla flows pause -s <source_id>

optional arguments:
  --source SOURCE, -s SOURCE
                        Source Id to be paused
  --dataset DATASET, -ds DATASET
                        Dataset ID to be paused
Examples:
    nexla flows pause -s 9311
"""
              },
            "activate":
             {"help": """Description:
    Activate the complete flow
Usage:
    nexla flows activate -s <source_id>

optional arguments:
  --source SOURCE, -s SOURCE
                        Source Id to be activated
  --dataset DATASET, -ds DATASET
                        Dataset ID to be activated
Examples:
    nexla flows activate -s 9311
"""
              },
             "delete":
             {"help": """Description:
    Delete the complete flow
Usage:
    nexla flows delete -s <source_id>

optional arguments:
  --source SOURCE, -s SOURCE
                        Source Id to be deleted
  --dataset DATASET, -ds DATASET
                        Dataset ID to be deleted
Examples:
    nexla flows delete -s 9311
"""
              },
         "import":
             {"help": """Description:
    Import Development Flow Specification from exported file.
Usage:
    nexla flows import [--input_file INPUT_FILE] [--properties PROPERTIES]

arguments:
  --input_file INPUT_FILE, -i INPUT_FILE
                        path of json file to be imported
  --properties PROPERTIES, -p PROPERTIES            
                        path of properties json file [optional]

Examples:
    nexla flows import -i ~/Desktop/export_file.json
    nexla flows import -i ~/Desktop/export_file.json -p ~/Desktop/export_file_properties.json
"""
              },
            "export":
             {"help": """Description:

   Export Development Flow Specification
Usage:
    nexla flows export [--source SOURCE] [--output_file OUTPUT_FILE] [options]

arguments:
  --source SOURCE, -s SOURCE
                        id of source to be exported
  --output_file OUTPUT_FILE, -o OUTPUT_FILE
                        name of output file to be exported

Options:
  -a, --all   Export all the flows of source(by default without entering the pipeline ids)

Examples:
    nexla flows export -s 9311 -o ~/Desktop/export_file.json
    nexla flows export -s 9311 -o ~/Desktop/export_file.json -a
"""
              },
            "update":
             {"help": """Description:
    Update the existing flow with updated configurations
Usage:
    nexla flows update [--input_file INPUT_FILE] [--properties PROPERTIES]

arguments:
    --input_file INPUT_FILE, -i INPUT_FILE
                        path of json file to be imported
    --properties PROPERTIES, -p PROPERTIES
                        path of properties json file

Examples:
    nexla flows update -i ~/Desktop/export_file.json -p ~/Desktop/export_file_properties.json
"""
              },
         "clone":
             {"help": """Description:
    Clone the flows within the environment
Usage:
    nexla flows clone [--sink SINK] [--dataset DATASET] [--reuse_creds REUSE_CREDS] [--copy_access_ctrl COPY_ACCESS_CTRL] [--copy_other_sinks COPY_OTHER_SINKS] [--payload PAYLOAD]

optional arguments:
  --sink SINK, -s SINK  Sink Id to be cloned
  --dataset DATASET, -ds DATASET
                        Dataset ID to be cloned
  --reuse_creds REUSE_CREDS, -rc REUSE_CREDS
                        'true' if you want to reuse credentials
  --copy_access_ctrl COPY_ACCESS_CTRL, -ac COPY_ACCESS_CTRL
                        'true' if you want to copy access controls
  --copy_other_sinks COPY_OTHER_SINKS, -os COPY_OTHER_SINKS
                        'true' if you want to copy other sinks
  --payload PAYLOAD, -p PAYLOAD
                        'true' if you want to give custom payloads

Examples:
    nexla flows clone --sink 9311
    nexla flows clone --dataset 14947
"""
              }

         },
    "lookup":
        {"help": """CLI for nexla lookups
Description:
    CLI to interact with Nexla lookups (static and dynamic).

Usage:
    nexla lookup <action> [parameters]

Actions:
    list
        List available lookups
    get
        Get a Lookup's configuration by id
    export
        Export a Lookup's configuration by id
    import
        Import a Lookup's configuration by id

Examples:
    nexla lookup list
    nexla lookup get 1556

""",
         "list":
             {"help": """Description:
    List of lookups available in nexla
Usage:
    nexla lookup list

Examples:
nexla lookup list
"""},
         "get":
             {"help": """Description:
Get Lookup's configuration by lookup id
Usage:
    nexla lookup get <lookup_id>

Examples:
    nexla lookup get 1556
"""
              },
            "import":
             {"help": """Description:
    Import Development static Lookup Specification from exported file.
Usage:
    nexla lookup import [--input_file INPUT_FILE]

arguments:
  --input_file INPUT_FILE, -i INPUT_FILE
                        path of json file to be imported

Examples:
    nexla lookup import -i ~/Desktop/export_file.json
"""
              },
            "export":
             {"help": """Description:
   Export Development static Lookup Specification by entering the lookup_id
Usage:
    nexla lookup export [--lookup LOOKUP] [--output_file OUTPUT_FILE]

arguments:
  --lookup LOOKUP, -l LOOKUP
                        id of source to be exported
  --output_file OUTPUT_FILE, -o OUTPUT_FILE
                        name of output file to be exported

Examples:
    nexla lookup export -l 1556 -o ~/Desktop/export_file.json
"""
              }

         },
    "credential":
        {"help": """CLI for nexla credentials
Description:
    CLI to interact with Nexla credentials

Usage:
    nexla credential <action> [parameters]

Actions:
    list
        List available credentials
    get
        Get credential's configuration by id

Examples:
    nexla credential list
    nexla credential get 5594

""",
         "list":
             {"help": """Description:
    List of credentials available in nexla
Usage:
    nexla credential list

Examples:
nexla credential list
"""},
         "get":
             {"help": """Description:
Get a credential's configuration by credential id
Usage:
    nexla credential get <credential_id>

Examples:
    nexla credential get 5594
"""
              }

         },
    "env":
        {"help": """Nexla environment configured for CLI
Description:
    Configure Nexla CLI environments.

Usage:
    nexla env <action>

Actions:
    list
        List configured environments
    switch
        Switch environment
    configure
        Configure an environment to connect to
    login
        Environment login
Examples:
    nexla env list
    nexla env switch

""",
         "list":
             {"help": """Description:
    List configured environments
Usage:
    nexla env list

Examples:
nexla env list
"""},
         "switch":
             {"help": """Description:
Switch environment
Usage:
    nexla env switch

Examples:
    nexla env switch
"""
              },
         "configure":
             {"help": """Description:
Configure an environment to access its resources. If this command is run, you will be prompted for configuration values such as Nexla Environment and API Key.
You can configure a name credential file by setting environment variable as 'NEXLA_CREDS_FILE'. If you not set this environment variable the default location is '~/.nxla_creds.json'.
If this config file does not exist, the Nexla CLI will create it for you.

Usage:
    nexla env configure

Examples:
    nexla env configure
"""},
            "login":
             {"help": """Description:
Environment login
Usage:
    nexla env login

Examples:
    nexla env login
"""
              }

         }
}
